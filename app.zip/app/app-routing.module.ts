import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SubcategoriesComponent } from './subcategories/subcategories.component';
import {BillComponent} from './bill/bill.component';
import {OrdersComponent} from './orders/orders.component';
import {GalleryComponent} from './gallery/gallery.component';
import {FeedbackComponent} from './feedback/feedback.component';
import {CartComponent} from './cart/cart.component';
import {HomeComponent} from './home/home.component';
import {LoginComponent} from './login/login.component';
import {RegisterComponent} from './register/register.component';
const routes: Routes = [
  { path: '', component:  HomeComponent },
  { path: 'cart', component: CartComponent },
  { path: 'bill', component: BillComponent },
  { path: 'orders', component: OrdersComponent },
  { path: 'gallery', component: GalleryComponent },
  { path: 'feedback', component: FeedbackComponent },
  { path: 'view/:name', component:SubcategoriesComponent},
  { path: 'register', component:RegisterComponent},
  { path: 'login', component:LoginComponent}
];
@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
