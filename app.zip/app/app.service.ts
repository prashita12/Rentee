import { Injectable } from '@angular/core';
import {AngularFirestore,AngularFirestoreCollection,AngularFirestoreDocument} from 'angularfire2/firestore';
import { Observable } from 'rxjs';
import { viewClassName } from '@angular/compiler';
@Injectable({
  providedIn: 'root'
})
export class AppService {
  items: Observable<any[]>;
  review: Observable<any[]>;
 
  name;data=[];
  subCategories: Observable<any[]>;
  placedOrder: Observable<any[]>;
  stars: Observable<any[]>;
   cartData=[];
   reviewData=[];
   count=0;price=0;
   status=[{value:false}];
  constructor(private db: AngularFirestore) {  

   }

  
   getCategories(){
    this.items= this.db.collection('category').valueChanges();
    return this.items;
   }
   setSubcategories(id,name){
    this.subCategories=this.db.collection('sub-category',ref=>ref.where('id','==',id)).valueChanges();
    this.name=name;
   }

   getSubcategories(){
     return this.subCategories;
   }

   addToCart(name,price,image){
     this.count=this.count + 1;
     this.price=this.price + price;
    this.cartData.push({name:name,price:price,quantity:1,date:new Date(),image:image,amount:price});
    console.log(this.cartData +" "+ this.count+" "+this.price);
   }

   addItemToDatabase(uname,unumber){
     this.cartData.forEach(element => {
       this.db.collection("cart").add({name:element.name,price:element.price,quantity:element.quantity,date:new Date(),image:element.image,amount:element.amount,username:uname,usernumber:unumber})
  .then(function(status) {
      console.log("Document successfully written!",status);
      return status;
  })
  .catch(function(error) {
      console.log("Error writing document: ", error);
  });
     });
   }
   getItemFromDatabase(uname,unumber){
    this.placedOrder=this.db.collection('cart',ref=>ref.where('username','==',uname).where('usernumber', "==", unumber)).valueChanges();
    return this.placedOrder;
   }

   addReview(uname,unumber,urating,uproduct)
   {
    this.reviewData.push({name:uname,rating:urating,contact:unumber,product:uproduct,date:new Date()});
   console.log(this.reviewData);
  
    this.reviewData.forEach(element => {
      this.db.collection("feedback").add({contact:element.contact,name:element.name,product_name:element.product,rating:element.rating})
 .then(function(status) {
    //  console.log("Document successfully written!",status);
    //  return status;
  
 })
 .catch(function(error) {
    //  console.log("Error writing document: ", error);
 });
    });
    
    this.review=this.db.collection('feedback',ref=>ref.where('product_name','==',uproduct)).valueChanges();
    return this.review;
   }

  


   
}


