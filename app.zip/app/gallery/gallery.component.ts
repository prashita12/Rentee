import { Component, OnInit } from '@angular/core';
import {faImage} from '@fortawesome/free-solid-svg-icons';
import {AppService} from '../app.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
faImage=faImage;
items: Observable<any[]>;
constructor(private service: AppService){
} 

  ngOnInit() {
    this.items= this.service.getCategories();
  }
  view(id,name){
    this.service.setSubcategories(id,name);
  }
}
