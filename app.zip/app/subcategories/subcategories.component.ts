import { Component, OnInit } from '@angular/core';
import { faUtensils,faSearch,faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import {AppService} from '../app.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-subcategories',
  templateUrl: './subcategories.component.html',
  styleUrls: ['./subcategories.component.css']
})
export class SubcategoriesComponent implements OnInit {
  faHome = faUtensils;
  faSearch=faSearch;
  faShopping=faShoppingCart;
  name;addedName;count=0;price=0;
  subCategories: Observable<any[]>;
  constructor(private service:AppService) { }

  ngOnInit() {
    this.name=this.service.name;
    this.price=this.service.price;
    this.count=this.service.count;
  }
  getItems(){
    this.subCategories= this.service.getSubcategories();
  }
  addItem(name,price,image){
   this.service.addToCart(name,price,image);
   this.price=this.service.price;
    this.count=this.service.count;
    this.addedName=name;
    var x = document.getElementById("snackbar");

    // Add the "show" class to DIV
    x.className = "show";

    // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);  
  }
}
