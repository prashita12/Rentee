import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {environment} from '../environments/environment';
import { AppComponent } from './app.component';
import {AngularFireModule} from 'angularfire2';
import {AngularFirestoreModule} from 'angularfire2/firestore';
import { AngularFireStorageModule } from 'angularfire2/storage';
import { SubcategoriesComponent } from './subcategories/subcategories.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './/app-routing.module';
import { BillComponent } from './bill/bill.component';
import { OrdersComponent } from './orders/orders.component';
import { GalleryComponent } from './gallery/gallery.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
// import { CoreComponent } from './core/core.component';
export const firebaseConfig = environment.config;
@NgModule({
  declarations: [
    AppComponent,
    SubcategoriesComponent,
    LoginComponent,
    BillComponent,
    OrdersComponent,
    GalleryComponent,
    FeedbackComponent,
    CartComponent,
    HomeComponent,
    RegisterComponent,
    // CoreComponent
  ],
  imports: [
    BrowserModule,
    FontAwesomeModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireStorageModule ,
    AngularFirestoreModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
