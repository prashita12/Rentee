import { Component, OnInit } from '@angular/core';
import {faShoppingCart,faChevronCircleUp,faChevronCircleDown,faTrash} from '@fortawesome/free-solid-svg-icons';
import {AppService} from '../app.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
faCart = faShoppingCart;
faChevronCircleUp=faChevronCircleUp;
faChevronCircleDown=faChevronCircleDown;
faTrash=faTrash;
userDetail={userName:'',userNumber:'',model:true};
cartItems=[];msg;subtotal=0;model=true;
succmsg;
user={ 
  name:'',
  number:''
};
  constructor(private service:AppService) { }

  ngOnInit() {
    if(this.service.cartData.length==0){
      this.msg="Cart is empty!!";
      if (localStorage.length > 0) {
      let key = localStorage.key(0);
      this.userDetail=JSON.parse(localStorage.getItem(key));
      this.model=this.userDetail.model;
      this.user.name=this.userDetail.userName;
      this.user.number=this.userDetail.userNumber;
      }
    }
    else {
      this.cartItems=this.service.cartData;
    this.msg='';
   this.cartItems.forEach(element => {
     this.subtotal=this.subtotal+element.amount;
   }); 
   if (localStorage.length > 0) {
   let key = localStorage.key(0);
      this.userDetail=JSON.parse(localStorage.getItem(key));
      this.model=this.userDetail.model;  
      this.user.name=this.userDetail.userName;
      this.user.number=this.userDetail.userNumber;
   }
  }
  }
  quantityPlus(i){
    this.subtotal=0;
    this.service.cartData[i].quantity+=1;
    this.service.cartData[i].amount=parseInt(this.service.cartData[i].amount) + parseInt(this.service.cartData[i].price);
    this.cartItems.forEach(element => {
      this.subtotal+=element.amount;
    }); 
  } 
  quantityMinus(i){
    if(this.service.cartData[i].quantity<=1){
      alert("Minimum quantity is 1");
    }
    else{
      this.subtotal=0;
      this.service.cartData[i].quantity-=1;
      this.service.cartData[i].amount=parseInt(this.service.cartData[i].amount) - parseInt(this.service.cartData[i].price);
      this.cartItems.forEach(element => {
      this.subtotal+=element.amount;
    }); 
   } 
  }
  removeItemById(i){
    this.service.cartData.splice(i,1);
    this.service.count-=1;
    this.service.price=0;
    this.subtotal=0;
  this.service.cartData.forEach(element => {
      this.service.price=this.service.price + element.price;
      this.subtotal+=element.amount;
    });
  }
  addItemstoDatabase(){
    if(this.service.cartData.length!=0){
      this.service.addItemToDatabase(this.user.name,this.user.number); 
   this.succmsg="Your order has been successfully placed! Go to My Orders to view your order.";
   var length=this.service.cartData.length;
   console.log(length);
   this.service.cartData=[];
   this.cartItems=[];
    }
    else{
      this.succmsg="Please add your order!";
    }
  }
  saveUser(){
    if(this.user.name!="" && this.user.number!=""){
      let myObj = { userName: this.user.name, userNumber: this.user.number,model:false };
      if (window.localStorage) {
      localStorage.setItem('userDetail', JSON.stringify(myObj));
      let key = localStorage.key(0);
      this.userDetail=JSON.parse(localStorage.getItem(key));
      this.model=this.userDetail.model;
      }
    }
  }
}
