import { Component, OnInit } from '@angular/core';
import {faUtensils} from '@fortawesome/free-solid-svg-icons'
import {AppService} from '../app.service';
import { Observable } from 'rxjs';
import { ModalService } from '../modal.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
faUtensils=faUtensils;
placedOrders: Observable<any[]>;
review: Observable<any[]>;
arr=[];avg:0;
userDetail={userName:'',userNumber:'',model:true};
user={ 
  name:'',
  number:'',
  rating:'5',
  product:'badminton'
};
  constructor(private service:AppService,private modalService: ModalService) { }

  ngOnInit() {
    if (localStorage.length > 0) {
      let key = localStorage.key(0);
      this.userDetail=JSON.parse(localStorage.getItem(key));
      this.placedOrders=this.service.getItemFromDatabase(this.userDetail.userName,this.userDetail.userNumber);
      }
   
  }
  addReview()
  {
    this.service.addReview(this.user.name,this.user.number,this.user.rating,this.user.product); 
    this.review=this.service.addReview(this.user.name,this.user.number,this.user.rating,this.user.product);
    this.review.forEach(element => {
      for(var i=0;i<element.length;i++)
      {
      this.arr.push(parseInt(element[i].rating));
      // this.avg=0+(element[i].rating);
    }
    });
    for(var i=0;i<this.arr.length;i++)
    {
      this.avg+=this.arr[i];
    }
    console.log(this.arr);
    console.log(this.avg);
  }

//  viewName(name)
//  {
// this.service.viewName(name);
//  }
// showModal = function (name) {
//  console.log(name);
//   };
}
