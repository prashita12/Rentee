import { Component, OnInit } from '@angular/core';
import {AppService} from '../app.service';
import { faHome } from '@fortawesome/free-solid-svg-icons';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  faHome = faHome;
  items: Observable<any[]>;

  constructor(private service: AppService){
  } 
  ngOnInit() {  
    this.items= this.service.getCategories();
  }
view(id,name){
  this.service.setSubcategories(id,name);
}
}
