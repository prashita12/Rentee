import { Component, OnInit } from '@angular/core';
import {faMoneyBill} from '@fortawesome/free-solid-svg-icons';
import {AppService} from '../app.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {
faBill=faMoneyBill;
placedOrders: Observable<any[]>;
userDetail;subtotal=0;arr=[];
today:number=Date.now();
  constructor(private service:AppService) { }

  ngOnInit() {
    if (localStorage.length > 0) {
      let key = localStorage.key(0);
      this.userDetail=JSON.parse(localStorage.getItem(key));
      this.placedOrders=this.service.getItemFromDatabase(this.userDetail.userName,this.userDetail.userNumber);
      this.placedOrders.forEach(element => {
        for(var i=0;i<element.length;i++)
        this.arr.push(element[i].amount);
      });
      }
      console.log(this.arr);
      this.arr.forEach(element => {
        console.log(element);
      });
  }

}
